import "./Styles.css";

function Header(props) {
  return (
    <div>
      <img className='logo' src='https://image4.owler.com/logo/antstream_owler_20190723_052530_original.png'></img>
    </div>
  );
}

export default Header;
